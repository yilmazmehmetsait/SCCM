Instructions

First, make sure you have Windows ADK 10 installed, then follow this guide:

1. Extract the Plugin to C:\Plugins\ADSIx64

2. Copy the following files from a Windows 10 x64 image/installation to C:\Plugins\ADSIx64

   adsldp.dll
   adsmsext.dll
   adsnt.dll
   mscoree.dll
   mscorier.dll
   mscories.dll

3. From an elevated PowerShell prompt, run the CreateBootImage_x64.ps1 script.

Below is a highlevel overview of what the CreateBootImage_x64.ps1 script does.

1. Using CopyPE, creates a x64 WinPE boot image in the C:\Setup\WinPE10_x64 folder

2. Using Mount-WindowsImage, mount your WinPE image (boot.wim) in the C:\Mount folder

3. Using DISM, add support for the following OCs

   winpe-hta.cab
   winpe-mdac.cab
   winpe-scripting.cab
   winpe-wmi.cab
  
4. Using DISM, injects the ADSI x64 plugin 

5. Copying the Connect_to_DC_Sample.vbs to C:\Mount\Windows\System32
  
6. Using Dismount-WindowsImage, commit the changes

7. Using oscdimg, creates a bootable ISO file named WinPE10_x64_ADSI.iso in the C:\ISO folder.

