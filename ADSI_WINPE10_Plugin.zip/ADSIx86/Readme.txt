Instructions

First, make sure you have Windows ADK 10 installed, then follow this guide:

1. Extract the Plugin to C:\Plugins\ADSIx86

2. Copy the following files from a Windows 10 x86 image/installation to C:\Plugins\ADSIx86

   adsldp.dll
   adsmsext.dll
   adsnt.dll
   mscoree.dll
   mscorier.dll
   mscories.dll

3. From an elevated PowerShell prompt, run the CreateBootImage_x86.ps1 script.

Below is a highlevel overview of what the CreateBootImage_x86.ps1 script does.

1. Using CopyPE, creates a x86 WinPE boot image in the C:\Setup\WinPE10_x86 folder

2. Using Mount-WindowsImage, mount your WinPE image (boot.wim) in the C:\Mount folder

3. Using DISM, add support for the following OCs

   winpe-hta.cab
   winpe-mdac.cab
   winpe-scripting.cab
   winpe-wmi.cab
  
4. Using DISM, injects the ADSI x86 plugin 

5. Copying the Connect_to_DC_Sample.vbs to C:\Mount\Windows\System32
  
6. Using Dismount-WindowsImage, commit the changes

7. Using oscdimg, creates a bootable ISO file named WinPE10_x86_ADSI.iso in the C:\ISO folder.

